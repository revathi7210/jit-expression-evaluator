/**
 * Tony Givargis
 * Copyright (C), 2023
 * University of California, Irvine
 *
 * CS 238P - Operating Systems
 * parser.c
 */

#include "lexer.h"
#include "parser.h"

#define MKD(parser,dag,operator) // create a node				
	\
	do {						\
		size_t n = sizeof (struct parser_dag);	\
		if (!((dag) = malloc(n))) {		\
			TRACE("out of memory");		\
			return NULL;			\
		}					\
		memset((dag), 0, n);			\
		(dag)->op = (operator);				\
		(dag)->id = ++(parser)->id;			\
	}						\
	while (0)

#define TRACE_ONCE(p,m)				\
	do {					\
		if (!(p)->stop) {		\
			(p)->stop = 1;		\
			TRACE(m);		\
		}				\
	} while (0)

struct parser {
	int id; /* global id */
	int stop;
	uint64_t i; /* current token */
	uint64_t n; /* total tokens */
	struct lexer *lexer;
	struct parser_dag *dag;
};

static void
free_dag(struct parser_dag *dag)
{
	if (dag) {
		free_dag(dag->left);
		free_dag(dag->right);
	}
	FREE(dag);
}

static const struct lexer_token *
next(const struct parser *parser) // it is returning the current token 
{
	static const struct lexer_token SENTINEL = { LEXER_OP_, 0.0 }; // it is a terminating condition when the parser is done it will return a sentinal which returns a type of token. No token either operator or value which can be NULL or 0

	if (parser->i < parser->n) {
		return lexer_lookup(parser->lexer, parser->i);
	}
	return &SENTINEL;
}

static int /* BOOL */
match(const struct parser *parser, enum lexer_token_op op)
{
	const struct lexer_token *token;

	if ((token = next(parser)) && (op == token->op)) { // it accesses the current token and checks if the operator matched with the input
		return 1;
	}
	return 0;
}

static void
forward(struct parser *parser) // parser is moving forward in both the lexer and the parse tree creating new nodes
{
	if (parser->i < parser->n) {
		++parser->i;
	}
}

/**
 * expr_primary : VAL
 *              | '(' expr ')'
 */

static struct parser_dag *expr(struct parser *parser);

static struct parser_dag *
expr_primary(struct parser *parser)
{
	struct parser_dag *dag;

	dag = NULL;
	if (match(parser, LEXER_OP_VAL)) {
		MKD(parser, dag, PARSER_DAG_VAL);
		dag->val = next(parser)->val;
		forward(parser);// incrementing the pointer to the next token
	}
	else if (match(parser, LEXER_OP_OPEN)) {// for openning braces
		forward(parser);
		if (!(dag = expr(parser))) {
			TRACE_ONCE(parser, "invalid sub-expression");
			return NULL;
		}
		if (!match(parser, LEXER_OP_CLOSE)) {
			TRACE_ONCE(parser, "expecting ')'");
			return NULL;
		}
		forward(parser);
	}
	return dag;
}

/**
 * expr_unary : [ '+' '-' ] exr_unary
 *            | expr_primary
 */

static struct parser_dag *
expr_unary(struct parser *parser)
{
	struct parser_dag *dag;

	dag = NULL;
	if (match(parser, LEXER_OP_ADD)) { // for add no new node is created because +5 is same as 5
		forward(parser);
		if (!(dag = expr_unary(parser))) {
			TRACE_ONCE(parser, "invalid unary '+' operand");
			return NULL;
		}
	}
	else if (match(parser, LEXER_OP_SUB)) { // for sub a new node is created because -5 is diff from 5
		MKD(parser, dag, PARSER_DAG_NEG);
		forward(parser);
		if (!(dag->right = expr_unary(parser))) {
			TRACE_ONCE(parser, "invalid unary '-' operand");
			return NULL;
		}
	}
	else {
		dag = expr_primary(parser);
	}
	return dag;
}

/**
 * expr_multiplicative_ : { [ '*' '/' ] expr_unary expr_multiplicative_ }
 *                      | ∅
 *
 * expr_multiplicative : expr_unary expr_multiplicative_
 */

static struct parser_dag *
expr_multiplicative_(struct parser *parser, struct parser_dag *left)
{
	const char * const TBL[] = { "*", "/" };
	struct parser_dag *dag;
	char buf[64];

	dag = left;
	for (;;) {
		if (match(parser, LEXER_OP_MUL)) {
			MKD(parser, dag, PARSER_DAG_MUL);
			dag->left = left;
			forward(parser);
		}
		else if (match(parser, LEXER_OP_DIV)) {
			MKD(parser, dag, PARSER_DAG_DIV);
			dag->left = left;
			forward(parser);
		}
		else {
			break;
		}
		if (!(dag->right = expr_unary(parser))) {
			safe_sprintf(buf,
				     sizeof (buf),
				     "invalid '%s' operand",
				     TBL[dag->op - PARSER_DAG_MUL]);
			TRACE_ONCE(parser, buf);
			return NULL;
		}
		if (!(dag = expr_multiplicative_(parser, dag))) {
			TRACE_ONCE(parser, 0);
			return NULL;
		}
	}
	return dag;
}

static struct parser_dag *
expr_multiplicative(struct parser *parser)
{
	struct parser_dag *dag;

	if (!(dag = expr_unary(parser))) {
		return NULL;
	}
	return expr_multiplicative_(parser, dag);
}

/**
 * expr_additive_ : { [ '+' '-' ] expr_multiplicative expr_additive_ }
 *                | ∅
 *
 * expr_additive : expr_multiplicative expr_additive_
 */

static struct parser_dag *
expr_additive_(struct parser *parser, struct parser_dag *left)
{
	const char * const TBL[] = { "+", "-" };
	struct parser_dag *dag;
	char buf[64];

	dag = left;
	for (;;) {
		if (match(parser, LEXER_OP_ADD)) {
			MKD(parser, dag, PARSER_DAG_ADD);
			dag->left = left;
			forward(parser);
		}
		else if (match(parser, LEXER_OP_SUB)) {
			MKD(parser, dag, PARSER_DAG_SUB);
			dag->left = left;
			forward(parser);
		}
		else {
			break;
		}
		if (!(dag->right = expr_multiplicative(parser))) {
			safe_sprintf(buf,
				     sizeof (buf),
				     "invalid '%s' operand",
				     TBL[dag->op - PARSER_DAG_MUL]);
			TRACE_ONCE(parser, buf);
			return NULL;
		}
		if (!(dag = expr_additive_(parser, dag))) {
			TRACE_ONCE(parser, 0);
			return NULL;
		}
	}
	return dag;
}

static struct parser_dag *
expr_additive(struct parser *parser)
{
	struct parser_dag *dag;

	if (!(dag = expr_multiplicative(parser))) {
		return NULL;
	}
	return expr_additive_(parser, dag);
}

/**
 * expr : expr_additive
 */

static struct parser_dag *
expr(struct parser *parser)
{
	return expr_additive(parser);
}

/**
 * top : expr
 */

static struct parser_dag *
top(struct parser *parser)
{
	struct parser_dag *dag;

	if (!(dag = expr(parser))) {
		TRACE_ONCE(parser, "invalid expression");
		return NULL;
	}
	if (!match(parser, LEXER_OP_)) {
		TRACE_ONCE(parser, "bogus trailing content");
		return NULL;
	}
	return dag;
}

struct parser *
parser_open(const char *s)
{
	struct parser *parser;

	assert( safe_strlen(s) );

	if (!(parser = malloc(sizeof (struct parser)))) {
		TRACE("out of memory");
		return NULL;
	}
	memset(parser, 0, sizeof (struct parser));
	if (!(parser->lexer = lexer_open(s)) ||
	    !(parser->n = lexer_size(parser->lexer)) ||
	    !(parser->dag = top(parser))) {
		parser_close(parser);
		TRACE(0);
		return NULL;
	}
	lexer_close(parser->lexer);
	parser->lexer = NULL;
	return parser;
}

void
parser_close(struct parser *parser)
{
	if (parser) {
		free_dag(parser->dag);
		lexer_close(parser->lexer);
		memset(parser, 0, sizeof (struct parser));
	}
	FREE(parser);
}

const struct parser_dag *
parser_dag(const struct parser *parser)
{
	assert( parser );

	return parser->dag;
}
